// Title:        Bottle Flipper Computer Vision Post Processing Node
// Modified:     31/10/2023
// Description:  This node is responsible for detecting and reporting the
//               3D position and orientation of the bottle to be flipped,
//               the position of the target marker where the bottle
//               should land, and if foriegn obstacles are in the workspace.
// ----------------------------------------------------------------------------

// Copyright 2016 Open Source Robotics Foundation, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// Standard headers
#include <chrono>
#include <functional>
#include <memory>
#include <string>
#include <iostream>

// ROS2 headers
//CV includes
#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"
#include "yolov8_msgs/msg/detection_array.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include "std_msgs/msg/bool.hpp"

//TF2 includes
#include "tf2/LinearMath/Quaternion.h"
#include "tf2_ros/transform_broadcaster.h"
#include <geometry_msgs/msg/transform_stamped.hpp>
#include <cmath>

using namespace std::chrono_literals;
using std::placeholders::_1;

//  CV Publisher and subscriber class
class PostProcess : public rclcpp::Node
{
public:
  // Post Processing node constructor
  PostProcess()
  : Node("postprocess"), count_(0)
  {
    subscription_ = this->create_subscription<yolov8_msgs::msg::DetectionArray>( // Subscriber topic name, msg type and queue size
      "yolo/detections", 10, std::bind(&PostProcess::topic_callback, this, _1));
    bottle_publisher_ = this->create_publisher<geometry_msgs::msg::PoseStamped>("bottle_pos", 10); // Publisher topic name, msg type and queue size. Publishes bottle position
    //marker_publisher_= this->create_publisher<geometry_msgs::msg::PoseStamped>("land_pos", 10); // Publishes marker position
    //obstacle_publisher_= this->create_publisher<std_msgs::msg::Bool>("is_obstacle", 10); // Publishes the presence of an obstacle
    //timer_ = this->create_wall_timer(500ms, std::bind(&PostProcess::timer_callback, this)); // Time interval for calling timer_callback function
    timer_ = create_wall_timer(std::chrono::milliseconds(100), std::bind(&PostProcess::publishDynamicTransform, this));
    tf_broadcaster_ = std::make_unique<tf2_ros::TransformBroadcaster>(*this);
  };

  mutable float bbox_x;
  mutable float bbox_y;
  mutable float bbox_z;
  
private:
  // Subscriber function that recieves data from yolo/detections topic and processes it.
  void topic_callback(const yolov8_msgs::msg::DetectionArray & msg) const
  {
    // Iterate through Yolo detection array and analyse objects
    for (long unsigned int i = 0; i < msg.detections.size(); i++) {
      if (msg.detections[i].class_name == "bottle") { // If the bottle is detected,
        auto bottlePos = geometry_msgs::msg::PoseStamped(); // Create message of type PoseStamped
        bottlePos.pose.position.x = msg.detections[i].bbox.center.position.x/400;
        bottlePos.pose.position.y = msg.detections[i].bbox.center.position.y/400;
        //bottlePos.pose.position.z = msg.detections[i].bbox.center.position.z;
        //bottlePos.pose.position.z = 0.12;

        bbox_x = bottlePos.pose.position.x;
        bbox_y = bottlePos.pose.position.y;
        //bbox_z = bottlePos.pose.position.z;
        bbox_z = 0.12;

        // Bottle orientation (Only use orientation.x!!!)
        //bottlePos.pose.orientation.x

        // RCLCPP_INFO prints the message to the terminal
        RCLCPP_INFO(this->get_logger(), "Bottle detected. 3D bounding box position: (%f,%f)", 
          bottlePos.pose.position.x, bottlePos.pose.position.y);
        bottle_publisher_->publish(bottlePos); // Publish message to "bottle_pos" topic
      }
      
      /*
      if (msg.detections[i].class_name == "marker") { // If a marker is detected,
        auto markerPos = geometry_msgs::msg::PoseStamped(); // Create message of type PoseStamped
          markerPos.pose.position.x = msg.detections[i].bbox3d.center.position.x;
          markerPos.pose.position.y = msg.detections[i].bbox3d.center.position.y;
          markerPos.pose.position.z = msg.detections[i].bbox3d.center.position.z;
        
        RCLCPP_INFO(this->get_logger(), "Marker detected. 3D bounding box position: (%f,%f,%f)", 
            markerPos.pose.position.x, markerPos.pose.position.y, markerPos.pose.position.z);
        marker_publisher_->publish(markerPos); // Publish message to "land_pos" topic
      }

      if (msg.detections[i].class_name != "bottle" && msg.detections[i].class_name != "marker") { // If the object is not a object of interest (obstacle),
        auto obstacle = std_msgs::msg::Bool(); // Create message of type Bool
        obstacle.data = true; // Set is_obstacle to "true" if a foreign object is detected

        RCLCPP_INFO(this->get_logger(), "Foriegn object detected! Notifying the path planning subsystem...");
        obstacle_publisher_->publish(obstacle); // Publish message to "is_obstacle" topic
      }
      */
    }
  }

  void publishDynamicTransform()
  {
    //double t = rclcpp::Clock().now().seconds();
    //double sin_value = std::sin(t);

    // Publish the static transform
    geometry_msgs::msg::TransformStamped transform_msg;
    transform_msg.header.stamp = this->get_clock()->now();
    transform_msg.header.frame_id = "camera_link";
    transform_msg.child_frame_id = "bottle";
    transform_msg.transform.translation.x = bbox_x;//bbox.x
    transform_msg.transform.translation.y = bbox_y;//bbox.y
    transform_msg.transform.translation.z = bbox_z;

    tf2::Quaternion q;
    q.setRPY(0, -M_PI / 4.0 , 0.0); 
    transform_msg.transform.rotation.x = q.x();
    transform_msg.transform.rotation.y = q.y();
    transform_msg.transform.rotation.z = q.z();
    transform_msg.transform.rotation.w = q.w();

    tf_broadcaster_->sendTransform(transform_msg);
  }

  // Declaration of fields
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Publisher<geometry_msgs::msg::PoseStamped>::SharedPtr bottle_publisher_; // Bottle publisher message type
  //rclcpp::Publisher<geometry_msgs::msg::PoseStamped>::SharedPtr marker_publisher_; // Marker publisher message type
  //rclcpp::Publisher<std_msgs::msg::Bool>::SharedPtr obstacle_publisher_; // Obstacle publisher message type
  rclcpp::Subscription<yolov8_msgs::msg::DetectionArray>::SharedPtr subscription_; // Subscriber message type
  size_t count_;

  //TF2 function
  std::unique_ptr<tf2_ros::TransformBroadcaster> tf_broadcaster_;
};



int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  std::cout << "File started..." << std::endl;
  rclcpp::spin(std::make_shared<PostProcess>());
  std::cout << "Post processing node started..." << std::endl;
  //rclcpp::spin(std::make_shared<DynamicExampleNode>());
  std::cout << "Dynamic transform is running..." << std::endl;
  rclcpp::shutdown();
  return 0;
}

# Title:         CV Subsystem Launch File
# Description:   This is the launch file for the CV subsystem for the Bottle Flip
#                Project. This only works when the Intel Realsense camera is used.
# Author:        Ethan Sing (z5259066)

# --------------------------------------------------------------------------------

import os

from ament_index_python.packages import get_package_share_directory

from launch import LaunchDescription
from launch_ros.actions import Node
from launch.substitutions import LaunchConfiguration, TextSubstitution
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription # For including other launch files
from launch.launch_description_sources import PythonLaunchDescriptionSource


def generate_launch_description():
    
    # ------------------------------------------------------------------
    # ARGUMENTS (Change input parameters by changing "default_value")
    # ------------------------------------------------------------------
    depth_module_profile = LaunchConfiguration("depth_module.profile")
    depth_module_profile_cmd = DeclareLaunchArgument(
        "depth_module.profile",
        default_value=TextSubstitution(text="1280x720x30"),
        description="Depth module profile")
    
    pointcloud_enable = LaunchConfiguration("pointcloud.enable")
    pointcloud_enable_cmd = DeclareLaunchArgument(
        "pointcloud.enable",
        default_value=TextSubstitution(text="true"),
        description="Should Pointcloud be enabled?")
        
    model = LaunchConfiguration("model")
    model_cmd = DeclareLaunchArgument(
        "model",
        default_value=TextSubstitution(text="yolov8n.pt"),
        description="Model name or path, i.e. sample size. Can be n, s, m, etc.")
    
    device = LaunchConfiguration("device")
    device_cmd = DeclareLaunchArgument(
        "device",
        default_value=TextSubstitution(text="cpu"),
        description="Device to use (GPU/CPU)")
    
    target_frame = LaunchConfiguration("target_frame")
    target_frame_cmd = DeclareLaunchArgument(
        "target_frame",
        default_value=TextSubstitution(text="camera_link"),
        description="Target frame to transform the 3D boxes")
        
    input_image_topic = LaunchConfiguration("input_image_topic")
    input_image_topic_cmd = DeclareLaunchArgument(
        "input_image_topic",
        default_value=TextSubstitution(text="/camera/color/image_raw"),
        description="Name of the input image topic")
        
    input_depth_topic = LaunchConfiguration("input_depth_topic")
    input_depth_topic_cmd = DeclareLaunchArgument(
        "input_depth_topic",
        default_value=TextSubstitution(text="/camera/depth/image_rect_raw"),
        description="Name of the input depth topic")


    # ------------------------------------------------------------------
    # NODES
    # ------------------------------------------------------------------
    realsense2_camera_node_cmd = IncludeLaunchDescription(
    	PythonLaunchDescriptionSource([os.path.join(
            get_package_share_directory('realsense2_camera'), 'launch'),
            '/rs_launch.py']),
        launch_arguments={"depth_module.profile": depth_module_profile,
            		  "pointcloud.enable": pointcloud_enable}.items(),
    )
    
    yolov8_3d_node_cmd = IncludeLaunchDescription(
    	PythonLaunchDescriptionSource([os.path.join(
            get_package_share_directory('yolov8_bringup'), 'launch'),
            '/yolov8_3d.launch.py']),
        launch_arguments={"model": model,
            		  "device": device,
            		  "target_frame": target_frame,
            		  "input_image_topic": input_image_topic,
            		  "input_depth_topic": input_depth_topic}.items(),
    )
    
    rviz2_node_cmd = Node(
        package="rviz2",
        executable="rviz2",
        name="rviz2_node"
    )
    
    post_process_node_cmd = Node(
        package="cv_post_process",
        executable="post_process",
        name="post_process_node"
    )
    
    static_tf_node_cmd = Node(
        package="static_tf",
        executable="static",
        name="static_tf_node"
    )
    

    # ------------------------------------------------------------------
    # ADD ACTIONS TO LAUNCH DESCRIPTION
    # ------------------------------------------------------------------

    ld = LaunchDescription()

    ld.add_action(depth_module_profile_cmd)
    ld.add_action(pointcloud_enable_cmd)
    ld.add_action(model_cmd)
    ld.add_action(device_cmd)
    ld.add_action(target_frame_cmd)
    ld.add_action(input_image_topic_cmd)
    ld.add_action(input_depth_topic_cmd)

    ld.add_action(realsense2_camera_node_cmd)
    ld.add_action(yolov8_3d_node_cmd)
    ld.add_action(rviz2_node_cmd)
    ld.add_action(post_process_node_cmd)
    ld.add_action(static_tf_node_cmd)

    return ld

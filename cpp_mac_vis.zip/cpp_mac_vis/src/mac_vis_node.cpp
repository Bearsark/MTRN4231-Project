// Title:        Bottle Flipper Machine Vision Node
// Modified:     12/10/2023
// Description:  This node is responsible for detecting and reporting the
//               3D position and orientation of the bottle to be flipped, as
//               well as the positions of the target zones where the bottle
//               should land.
// ----------------------------------------------------------------------------

// Copyright 2016 Open Source Robotics Foundation, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// Standard headers
#include <chrono>
#include <functional>
#include <memory>
#include <string>

// ROS2 headers
#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"
#include "yolov8_msgs/msg/detection_array.hpp"
#include "geometry_msgs/msg/pose.hpp"

using namespace std::chrono_literals;
using std::placeholders::_1;

// Publisher and subscriber class
class MacVis : public rclcpp::Node
{
public:
  // MacVis node constructor
  MacVis()
  : Node("macvis"), count_(0)
  {
    subscription_ = this->create_subscription<yolov8_msgs::msg::DetectionArray>( // Subscriber topic name, msg type and queue size
      "yolo/detections", 10, std::bind(&MacVis::topic_callback, this, _1));
    publisher_ = this->create_publisher<geometry_msgs::msg::Pose>("bottle_pos", 10); // Publisher topic name, msg type and queue size
    //timer_ = this->create_wall_timer(500ms, std::bind(&MacVis::timer_callback, this)); // Time interval for calling timer_callback function
  }
  
private:
  // Subscriber function that recieves data from yolo/detections topic and processes it.
  void topic_callback(const yolov8_msgs::msg::DetectionArray & msg) const
  {
    // Determine the bottle from the detected objects
    for (int i = 0; i <= msg.detections.size(); i++) {
      if (msg.detections[i].class_name.c_str() == "bottle") {
        //auto bottle = msg.detections[i];

        // RCLCPP_INFO prints the message to the terminal
        RCLCPP_INFO(this->get_logger(), "Yolov8 bottle center pixel position detected: (%f,%f)", 
          msg.detections[i].bbox.center.position.x, msg.detections[i].bbox.center.position.y);

        // Do something with the bottle here...
        // The bottle lid is approximately 1/12 the length of the bottle down from the top
        auto bottlePos = geometry_msgs::msg::Pose(); // Create message of type Pose
        bottlePos.position.x = msg.detections[i].bbox.center.position.x;
        bottlePos.position.y = msg.detections[i].bbox.center.position.y - (msg.detections[i].bbox.size.y * 5/12);
        bottlePos.position.z = 42; // Height of the bottle cap, change later

        // Bottle orientation (Only use orientation.x!!!)
        //bottlePos.orientation.x

        RCLCPP_INFO(this->get_logger(), "Bottle cap position: (%f,%f,%f)", bottlePos.position.x, 
          bottlePos.position.y, bottlePos.position.z); 
        publisher_->publish(bottlePos); // Publish message to topic
      }
    }
    
  }
  
  /*
  // Publisher function that sets message data and publishes messages
  void timer_callback() 
  {
    RCLCPP_INFO(this->get_logger(), "Bottle position: (%f,%f,%f)", bottlePos.position.x, 
        bottlePos.position.y, bottlePos.position.z); 
    publisher_->publish(bottlePos); // Publish message to topic
  }
  */

  // Declaration of fields
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Publisher<geometry_msgs::msg::Pose>::SharedPtr publisher_; // Publisher message type
  rclcpp::Subscription<yolov8_msgs::msg::DetectionArray>::SharedPtr subscription_; // Subscriber message type
  size_t count_;
};



int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<MacVis>());
  rclcpp::shutdown();
  return 0;
}

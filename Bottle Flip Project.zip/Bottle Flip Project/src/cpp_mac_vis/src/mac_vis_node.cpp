// Title:        Bottle Flipper Machine Vision Node
// Modified:     12/10/2023
// Description:  This node is responsible for detecting and reporting the
//               3D position and orientation of the bottle to be flipped, as
//               well as the positions of the target zones where the bottle
//               should land.
// ----------------------------------------------------------------------------

// Copyright 2016 Open Source Robotics Foundation, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// Standard headers
#include <chrono>
#include <functional>
#include <memory>
#include <string>

// ROS2 headers
#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp" // Change this later to Yolo Detection type

using namespace std::chrono_literals;
using std::placeholders::_1;

// Publisher and subscriber class
class MacVis : public rclcpp::Node
{
public:
  // MacVis node constructor
  MacVis()
  : Node("macvis"), count_(0)
  {
    publisher_ = this->create_publisher<std_msgs::msg::String>("bottle_pos", 10); // Publisher topic name, msg type and queue size
    timer_ = this->create_wall_timer(500ms, std::bind(&MacVis::timer_callback, this)); // Time interval for calling timer_callback function
    subscription_ = this->create_subscription<std_msgs::msg::String>( // Subscriber topic name, msg type and queue size
      "yolo_detections_3D or whatever its called", 10, std::bind(&MacVis::topic_callback, this, _1)); // CHANGE TOPIC NAME LATER
  }
  
private:
  // Publisher function that sets message data and publishes messages
  void timer_callback() 
  {
    auto message = std_msgs::msg::String(); // Message type and details
    message.data = "Hello, world! " + std::to_string(count_++);
    RCLCPP_INFO(this->get_logger(), "Bottle position: '%s'", message.data.c_str()); // ECLCPP_INFO nsures message is printed to console
    publisher_->publish(message);
  }

  // Subscriber function that recieves the message data and writes it to the console.
  void topic_callback(const std_msgs::msg::String & msg) const
  {
    RCLCPP_INFO(this->get_logger(), "Yolo position recieved: '%s'", msg.data.c_str());
  }
  
  // Declaration of fields
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr publisher_; // Publisher message type
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr subscription_; // Subscriber message type
  size_t count_;
};

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<MacVis>());
  rclcpp::shutdown();
  return 0;
}
